package py4j.examples;

public interface InterfaceA {

}
