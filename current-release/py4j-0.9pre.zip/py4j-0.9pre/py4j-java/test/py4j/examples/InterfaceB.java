package py4j.examples;

public interface InterfaceB {

	public InterfaceA getA();

}
