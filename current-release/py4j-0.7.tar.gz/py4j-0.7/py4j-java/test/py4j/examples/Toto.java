package py4j.examples;

public class Toto extends Region {

}
