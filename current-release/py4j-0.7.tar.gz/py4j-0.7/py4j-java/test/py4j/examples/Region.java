package py4j.examples;

public class Region {
	
	public String m1() {
		return "hello";
	}
	
	public String wait(String s1, int i) {
		return "yo";
	}

}
