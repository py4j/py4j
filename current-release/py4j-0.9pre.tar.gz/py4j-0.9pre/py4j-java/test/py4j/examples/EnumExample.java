package py4j.examples;

public class EnumExample {

	public enum MyEnum {
		FOO;
	}

	public class InnerClass {
		public final static String MY_CONSTANT2 = "HELLO2";
	}

}
